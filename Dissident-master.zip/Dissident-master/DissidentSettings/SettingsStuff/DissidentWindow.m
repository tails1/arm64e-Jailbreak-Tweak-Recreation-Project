#import "DissidentWindow.h"

@implementation DissidentWindow

- (float)level
{
  return 99999;
}

@end
