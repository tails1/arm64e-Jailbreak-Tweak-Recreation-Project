#import <UIKit/UIKit.h>

#import "../../Dissident.h"

@interface DissidentSettingsIndividual : UIViewController <UITableViewDataSource, UITableViewDelegate>

@property (nonatomic, strong) UITableView *tableView;

@end
