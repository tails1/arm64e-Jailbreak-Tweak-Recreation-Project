#import <UIKit/UIKit.h>

#import "../../Dissident.h"

@interface DissidentSettingsOther : UIViewController <UITableViewDataSource, UITableViewDelegate>

@property (nonatomic, strong) UITableView *tableView;

@end
