#import <UIKit/UIKit.h>

@interface DissidentWindow : UIView
- (float)level;
@end
