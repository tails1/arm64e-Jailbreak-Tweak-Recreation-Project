#import <UIKit/UIKit.h>
#import <Social/Social.h>

#import "../../Dissident.h"

@interface DissidentSettings : UIViewController <UITableViewDataSource, UITableViewDelegate>

@property (nonatomic, strong) UITableView *tableView;

@end
