#import <UIKit/UIKit.h>

#import "../../Dissident.h"

@interface DissidentUITableViewCell : UITableViewCell

@end
