#import "../../Dissident.h"

@interface DissidentActivatorActionToggleForcedBackgroundingTemporary : NSObject <LAListener>

@end
