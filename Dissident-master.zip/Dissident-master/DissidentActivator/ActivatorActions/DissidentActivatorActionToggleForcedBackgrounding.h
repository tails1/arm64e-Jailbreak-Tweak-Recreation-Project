#import "../../Dissident.h"

@interface DissidentActivatorActionToggleForcedBackgrounding : NSObject <LAListener>

@end
